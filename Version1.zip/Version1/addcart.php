<?php
include_once "file_storage.php";
$product_id = $_GET['product_id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-web";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// read data from mysql
$sql = "SELECT * FROM `catelogs`  WHERE product_id = '$product_id' ";
// fetch data from mysql
$result = $conn->query($sql);
// display session id
session_start();
$userID = session_id();
// create table of products
print "<table border='1'>";
// ser_session_id	prod_name	prod_price	prod_quantity	prod_category	prod_id
print "<tr><th>Product ID</th><th>Product Name</th><th>Product Category</th><th>Product Description</th><th>Product Price</th><th>Product Quantity</th><th>Add to Cart</th></tr>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    ?>
<tr>
    <td><?php echo $userID; ?></td>
    <td><?php echo $row['product_id']; ?></td>
    <td><?php print $row['product_name']; ?></td>
    <td><?php print $row['product_category']; ?></td>
    <td><?php print $row['product_price']; ?></td>
    <td><?php print $row['product_quantity']; ?></td>
    <!-- <td><?php print $row['product_price'] * $row['product_quantity']; ?></td> -->
    <?php $sql1 = "INSERT INTO `cart` (`user_session_id`,`prod_name`,`prod_price`, `prod_quantity`,`prod_category`,`prod_id`) VALUES ('$userID', '$row[product_name]', '$row[product_price]', '$row[product_quantity]', '$row[product_category]', '$row[product_id]')";
    $result1 = $conn->query($sql1); ?>
    <!-- remove from cart -->
    <td><a href="removecart.php?product_id=<?php print $row['product_id']; ?>">Remove from Cart</a></td>
</tr>
<?php
}
} else {
    print "0 results";
}
$conn->close();
?>

